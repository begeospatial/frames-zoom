# streamlit-custom-component

Streamlit component that allows you zoom, crop and render a backgound image to be segmented inside a rectangle box.

## Installation instructions

```sh
pip install streamlit-frames-zoom-component
```

## Usage instructions

```python
import streamlit as st

from frames_zoom import frames_zoom

```